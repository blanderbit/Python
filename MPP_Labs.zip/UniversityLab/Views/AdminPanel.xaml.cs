﻿using System.Windows.Controls;

namespace UniversityLabApp.Views
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class AdminPanel : Page
    {
        public AdminPanel()
        {
            InitializeComponent();            
        }        
    }
}
