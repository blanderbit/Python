﻿using System.Windows;
using System.Windows.Controls;

namespace UniversityLabApp.Views
{
    /// <summary>
    /// Логика взаимодействия для StudentPanel.xaml
    /// </summary>
    public partial class StudentPanel : Page
    {
        public StudentPanel()
        {
            InitializeComponent();
        }

        private void BackToHomepageClick(object sender, System.Windows.RoutedEventArgs e)
        {
            Application.Current.MainWindow.Content = new MainPanel();
        }
    }
}
