﻿using System.Windows.Controls;

namespace UniversityLabApp.Views
{
    /// <summary>
    /// Логика взаимодействия для AllStudents.xaml
    /// </summary>
    public partial class AllStudents : Page
    {
        public AllStudents()
        {
            InitializeComponent();
        }
    }
}
