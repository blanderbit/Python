﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using UniversityLabApp.Models;

namespace UniversityLabApp.Views
{
    /// <summary>
    /// Логика взаимодействия для MainPanel.xaml
    /// </summary>
    public partial class MainPanel : Page
    {
        private readonly Dictionary<string, string> adminRole = new Dictionary<string, string>();
        private readonly Dictionary<string, string> studentRole = new Dictionary<string, string>();

        public MainPanel()
        {
            InitializeComponent();

            adminRole.Add("admin", "admin666");
            studentRole.Add("guest", "guest");
        }

        private void SignInClick(object sender, RoutedEventArgs e)
        {
            errorHint.Visibility = Visibility.Collapsed;

            if (adminRole.ContainsKey(login.Text))
            {
                if (adminRole[login.Text] == password.Password)
                {
                    UserRole.Role =  UserType.Admin;
                    Application.Current.MainWindow.Content = new AdminPanel();
                }
            }
            else if (studentRole.ContainsKey(login.Text))
            {
                if (studentRole[login.Text] == password.Password)
                {
                    UserRole.Role = UserType.Guest;
                    Application.Current.MainWindow.Content = new StudentPanel();
                }
            }
            else
            {
                errorHint.Visibility = Visibility.Visible;
            }
        }
    }
}
