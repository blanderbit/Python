﻿using System.Windows.Controls;

namespace UniversityLabApp.Views
{
    /// <summary>
    /// Логика взаимодействия для ViewReport.xaml
    /// </summary>
    public partial class ViewReport : Page
    {
        public ViewReport()
        {
            InitializeComponent();
        }
    }
}
