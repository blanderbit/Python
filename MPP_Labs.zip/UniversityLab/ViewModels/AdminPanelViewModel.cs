﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Windows;
using System.Windows.Input;
using UniversityLabApp.Common;
using UniversityLabApp.Models;
using UniversityLabApp.Views;

namespace UniversityLabApp.ViewModels
{
    public class AdminPanelViewModel : ObservableObject
    {
        private List<string> specializations = new List<string>();

        public List<string> Specializations
        {
            get => specializations;
            set
            {
                specializations = value;
                RaisePropertyChangedEvent("Specializations");
            }
        }

        private List<string> subjects = new List<string>();

        public List<string> Subjects
        {
            get => subjects;
            set
            {
                subjects = value;
                RaisePropertyChangedEvent("Subjects");
            }
        }

        private ObservableCollection<AdminCertification> certifications = new ObservableCollection<AdminCertification>();

        public ObservableCollection<AdminCertification> Certifications
        {
            get => certifications;
            set
            {
                certifications = value;
                RaisePropertyChangedEvent("Certifications");
            }
        }

        private string firstCert = String.Empty;

        public string FirstCert
        {
            get => firstCert;
            set
            {
                firstCert = value;
                RaisePropertyChangedEvent("FirstCert");
            }
        }

        private string secondCert = String.Empty;

        public string SecondCert
        {
            get => secondCert;
            set
            {
                secondCert = value;
                RaisePropertyChangedEvent("SecondCert");
            }
        }

        private string thirdCert = String.Empty;

        public string ThirdCert
        {
            get => thirdCert;
            set
            {
                thirdCert = value;
                RaisePropertyChangedEvent("ThirdCert");
            }
        }

        private string nameSpecialization;

        public string NameSpecialization
        {
            get => nameSpecialization;
            set
            {
                nameSpecialization = value;
                RaisePropertyChangedEvent("NameSpecialization");
            }
        }

        private string countSpot;

        public string CountSpot
        {
            get => countSpot;
            set
            {
                countSpot = value;
                RaisePropertyChangedEvent("CountSpot");
            }
        }


        public AdminPanelViewModel()
        {
            ReadDataFromFile(specializations, "subjects.txt");
            ReadDataFromFile(subjects, "schoolsubjects.txt");
            
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(ObservableCollection<AdminCertification>));

            using (FileStream fs = new FileStream("specializations.json", FileMode.OpenOrCreate))
            {
                Certifications = (ObservableCollection<AdminCertification>)jsonFormatter.ReadObject(fs);
            }
        }

        private void ReadDataFromFile(List<string> list, string nameFile)
        {
            string path = Directory.GetCurrentDirectory();
            var pathToFile = path.Remove(path.Remove(path.LastIndexOf('\\')).LastIndexOf('\\')) + $"\\Data\\{nameFile}";

            try
            {
                using (StreamReader sr = new StreamReader(pathToFile, System.Text.Encoding.Default))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        list.Add(line);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public ICommand AddSpecializationCommand
        {
            get { return new DelegateCommand(AddSpecializationClick); }
        }

        public ICommand ViewReportCommand
        {
            get { return new DelegateCommand(ViewReport); }
        }

        public ICommand ShowAllStudentsCommand
        {
            get { return new DelegateCommand(ShowAllStudents); }
        }

        public ICommand BackToHomepageCommand
        {
            get { return new DelegateCommand(BackToHomepage); }
        }

        private void ShowAllStudents()
        {
            Application.Current.MainWindow.Content = new AllStudents();
        }

        private void AddSpecializationClick()
        {
            List<CertificateModel> listCert = new List<CertificateModel>
            {
                new CertificateModel
                {
                    NameSubject = FirstCert.ToString()
                },
                new CertificateModel
                {
                    NameSubject = SecondCert.ToString()
                },
                new CertificateModel
                {
                    NameSubject = ThirdCert.ToString()
                }
            };

            var adminCert = new AdminCertification
            {
                Name = NameSpecialization.ToString(),
                Spot = Convert.ToInt32(CountSpot.ToString()),
                CertificateList = listCert
            };

            Certifications.Add(adminCert);
            WriteInFile(adminCert);
        }

        private void WriteInFile(AdminCertification adminCert)
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<AdminCertification>));

            // Read json file
            List<AdminCertification> certs = new List<AdminCertification>();
            using (FileStream fs = new FileStream("specializations.json", FileMode.OpenOrCreate))
            {
                certs = (List<AdminCertification>)jsonFormatter.ReadObject(fs);
            }

            certs.Add(adminCert);
            using (FileStream fs = new FileStream("specializations.json", FileMode.OpenOrCreate))
            {
                jsonFormatter.WriteObject(fs, certs);
            }
        }

        private void ViewReport()
        {
            Application.Current.MainWindow.Content = new ViewReport();
        }

        private void BackToHomepage()
        {
            Application.Current.MainWindow.Content = new MainPanel();
        }
    }
}
