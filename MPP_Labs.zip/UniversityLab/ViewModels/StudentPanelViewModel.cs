﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Windows;
using System.Windows.Input;
using UniversityLabApp.Common;
using UniversityLabApp.Models;
using UniversityLabApp.Views;

namespace UniversityLabApp.ViewModels
{
    public class StudentPanelViewModel : ObservableObject
    {
        #region Properties

        private string firstname = string.Empty;

        public string Firstname
        {
            get => firstname;
            set
            {
                firstname = value;
                RaisePropertyChangedEvent("Firstname");
            }
        }

        private string secondname = string.Empty;

        public string Secondname
        {
            get => secondname;
            set
            {
                secondname = value;
                RaisePropertyChangedEvent("Secondname");
            }
        }

        private string patronymic = string.Empty;

        public string Patronymic
        {
            get => patronymic;
            set
            {
                patronymic = value;
                RaisePropertyChangedEvent("Patronymic");
            }
        }

        private DateTime birthday = DateTime.Now;

        public DateTime Birthday
        {
            get => birthday;
            set
            {
                birthday = value;
                RaisePropertyChangedEvent("Birthday");
            }
        }

        private int average;

        public int Average
        {
            get => average;
            set
            {
                average = value;
                RaisePropertyChangedEvent("Average");
            }
        }

        private string firstCert = String.Empty;

        public string FirstCert
        {
            get => firstCert;
            set
            {
                firstCert = value;
                RaisePropertyChangedEvent("FirstCert");
            }
        }

        private string secondCert = String.Empty;

        public string SecondCert
        {
            get => secondCert;
            set
            {
                secondCert = value;
                RaisePropertyChangedEvent("SecondCert");
            }
        }

        private string thirdCert = String.Empty;

        public string ThirdCert
        {
            get => thirdCert;
            set
            {
                thirdCert = value;
                RaisePropertyChangedEvent("ThirdCert");
            }
        }

        private int firstCertGrade = 0;

        public int FirstCertGrade
        {
            get => firstCertGrade;
            set
            {
                firstCertGrade = value;
                RaisePropertyChangedEvent("FirstCertGrade");
            }
        }

        private int secondCertGrade = 0;

        public int SecondCertGrade
        {
            get => secondCertGrade;
            set
            {
                secondCertGrade = value;
                RaisePropertyChangedEvent("SecondCertGrade");
            }
        }

        private int thirdCertGrade = 0;

        public int ThirdCertGrade
        {
            get => thirdCertGrade;
            set
            {
                thirdCertGrade = value;
                RaisePropertyChangedEvent("ThirdCertGrade");
            }
        }

        private string nameExtra = String.Empty;

        public string NameExtra
        {
            get => nameExtra;
            set
            {
                nameExtra = value;
                RaisePropertyChangedEvent("NameExtra");
            }
        }

        private int extraGrade = 0;

        public int ExtraGrade
        {
            get => extraGrade;
            set
            {
                extraGrade = value;
                RaisePropertyChangedEvent("ExtraGrade");
            }
        }

        private List<string> subjects = new List<string>();

        public List<string> Subjects
        {
            get => subjects;
            set
            {
                subjects = value;
                RaisePropertyChangedEvent("Subjects");
            }
        }

        private List<string> specializations = new List<string>();

        public List<string> Specializations
        {
            get => specializations;
            set
            {
                specializations = value;
                RaisePropertyChangedEvent("Specializations");
            }
        }

        private ObservableCollection<string> specializationsSelected = new ObservableCollection<string>();

        public ObservableCollection<string> SpecializationsSelected
        {
            get => specializationsSelected;
            set
            {
                specializationsSelected = value;
                RaisePropertyChangedEvent("SpecializationsSelected");
            }
        }

        private string selectedSpec;

        public string SelectedSpec
        {
            get => selectedSpec;
            set
            {
                selectedSpec = value;
                RaisePropertyChangedEvent("SelectedSpec");
            }
        }

        #endregion

        private List<StudentModel> listStudent = new List<StudentModel>();

        public StudentPanelViewModel()
        {
            ReadDataFromFile(subjects, "schoolsubjects.txt");
            ReadDataFromFile(specializations, "subjects.txt");
        }

        public ICommand AddStudentCommand
        {
            get { return new DelegateCommand(AddStudent); }
        }

        public ICommand ViewReportCommand
        {
            get { return new DelegateCommand(ViewReport); }
        }

        public ICommand AddSpecializationCommand
        {
            get { return new DelegateCommand(AddSpecialization); }
        }

        private void ViewReport()
        {
            Application.Current.MainWindow.Content = new ViewReport();
        }

        private void AddSpecialization()
        {
            if (SpecializationsSelected.Count <= 2)
            {
                SpecializationsSelected.Add(SelectedSpec);
            }
        }

        private void ReadDataFromFile(List<string> list, string nameFile)
        {
            string path = Directory.GetCurrentDirectory();
            var pathToFile = path.Remove(path.Remove(path.LastIndexOf('\\')).LastIndexOf('\\')) + $"\\Data\\{nameFile}";

            try
            {
                using (StreamReader sr = new StreamReader(pathToFile, System.Text.Encoding.Default))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        list.Add(line);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private void AddStudent()
        {
            var student = new StudentModel
            {
                FirstName = Firstname,
                SecondName = Secondname,
                Patronymic = Patronymic,
                Birthday = Birthday,
                AverageGrade = Average,
                Certificates = new List<CertificateModel>
                {
                    new CertificateModel
                    {
                        NameSubject = FirstCert.ToString(),
                        Grade = Convert.ToDouble(FirstCertGrade)
                    },
                    new CertificateModel
                    {
                        NameSubject = SecondCert.ToString(),
                        Grade = Convert.ToDouble(SecondCertGrade)
                    },
                    new CertificateModel
                    {
                        NameSubject = ThirdCert.ToString(),
                        Grade = Convert.ToDouble(ThirdCertGrade)
                    }
                },
                ExtraPoints = new Dictionary<string, int>() { { NameExtra, ExtraGrade } },
                Specializations = SpecializationsSelected
            };
            listStudent.Add(student);
            WriteInfoStudents(student);

            MessageBox.Show("Student added in list", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            ClearFields();
        }

        private void ClearFields()
        {
            Firstname = String.Empty;
            Secondname = String.Empty;
            Patronymic = String.Empty;

            Birthday = DateTime.Now;
            Average = 0;
            FirstCertGrade = 0;
            SecondCertGrade = 0;
            ThirdCertGrade = 0;

            NameExtra = String.Empty;
            ExtraGrade = 0;

            SpecializationsSelected.Clear();
        }

        private void WriteInfoStudents(StudentModel student)
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<StudentModel>));

            // Read json file
            List<StudentModel> students = new List<StudentModel>();
            using (FileStream fs = new FileStream("students.json", FileMode.OpenOrCreate))
            {
                students = (List<StudentModel>)jsonFormatter.ReadObject(fs);
            }

            students.Add(student);

            using (FileStream fs = new FileStream("students.json", FileMode.OpenOrCreate))
            {
                jsonFormatter.WriteObject(fs, students);
            }

        }      
    }
}
