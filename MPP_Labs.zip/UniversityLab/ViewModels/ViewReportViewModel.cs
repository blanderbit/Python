﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Windows;
using System.Windows.Input;
using UniversityLabApp.Common;
using UniversityLabApp.Models;
using UniversityLabApp.Views;

namespace UniversityLabApp.ViewModels
{
    public class ViewReportViewModel : ObservableObject
    {
        private List<StudentModel> allStudentList = new List<StudentModel>();

        public List<StudentModel> AllStudentList
        {
            get => allStudentList;
            set
            {
                allStudentList = value;
                RaisePropertyChangedEvent("AllStudentList");
            }
        }

        private List<AdminCertification> adminCertificationsList = new List<AdminCertification>();

        public List<AdminCertification> AdminCertificationsList
        {
            get => adminCertificationsList;
            set
            {
                adminCertificationsList = value;
                RaisePropertyChangedEvent("AdminCertificationsList");
            }
        }

        private AdminCertification selectedCert;

        public AdminCertification SelectedCert
        {
            get => selectedCert;
            set
            {
                selectedCert = value;
                RaisePropertyChangedEvent("SelectedCert");
            }
        }

        private Visibility visibleStatus = Visibility.Hidden;

        public Visibility VisibleStatus
        {
            get => visibleStatus;
            set
            {
                visibleStatus = value;
                RaisePropertyChangedEvent("VisibleStatus");
            }
        }


        public ViewReportViewModel()
        {
            AdminCertificationsList = ReadInfoAdminCertification();
            AllStudentList = ReadInfoStudents();
        }

        private List<AdminCertification> ReadInfoAdminCertification()
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<AdminCertification>));

            // Read json file
            List<AdminCertification> certs = new List<AdminCertification>();
            using (FileStream fs = new FileStream("specializations.json", FileMode.OpenOrCreate))
            {
                certs = (List<AdminCertification>)jsonFormatter.ReadObject(fs);
            }

            return certs;
        }

        private List<StudentModel> ReadInfoStudents()
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<StudentModel>));

            List<StudentModel> students = new List<StudentModel>();

            using (FileStream fs = new FileStream("students.json", FileMode.OpenOrCreate))
            {
                students = (List<StudentModel>)jsonFormatter.ReadObject(fs);
            }

            return students;
        }

        public ICommand BackToAdminPageCommand
        {
            get { return new DelegateCommand(BackToAdminPage); }
        }

        private void BackToAdminPage()
        {
            Application.Current.MainWindow.Content = 
                UserRole.Role == UserType.Admin ? new AdminPanel() : (object)new StudentPanel();
        }

        public ICommand FindCommand
        {
            get { return new DelegateCommand(Find); }
        }

        private void Find()
        {
            AllStudentList = ReadInfoStudents();
            var list = AllStudentList.FindAll(item => item.Specializations.Contains(SelectedCert.Name));

            AllStudentList = list.OrderByDescending(i => i.AverageGrade).ToList();
            VisibleStatus = Visibility.Visible;

            for (int i = 0; i < AllStudentList.Count; i++)
            {
                if (i <= SelectedCert.Spot -1)
                {
                    AllStudentList[i].IsEnrolled = true;
                }
                else
                {
                    AllStudentList[i].IsEnrolled = false;
                }
            }
        }

        private void ReadDataFromFile(List<string> list, string nameFile)
        {
            string path = Directory.GetCurrentDirectory();
            var pathToFile = path.Remove(path.Remove(path.LastIndexOf('\\')).LastIndexOf('\\')) + $"\\Data\\{nameFile}";

            try
            {
                using (StreamReader sr = new StreamReader(pathToFile, System.Text.Encoding.Default))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        list.Add(line);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
