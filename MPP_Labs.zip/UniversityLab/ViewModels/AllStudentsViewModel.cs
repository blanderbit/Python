﻿using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Windows;
using System.Windows.Input;
using UniversityLabApp.Common;
using UniversityLabApp.Models;
using UniversityLabApp.Views;

namespace UniversityLabApp.ViewModels
{
    public class AllStudentsViewModel: ObservableObject
    {
        private List<StudentModel> allStudentList = new List<StudentModel>();

        public List<StudentModel> AllStudentList
        {
            get => allStudentList;
            set
            {
                allStudentList = value;
                RaisePropertyChangedEvent("AllStudentList");
            }
        }

        public AllStudentsViewModel()
        {
            AllStudentList = ReadInfoStudents();
        }

        private List<StudentModel> ReadInfoStudents()
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<StudentModel>));

            List<StudentModel> students = new List<StudentModel>();

            using (FileStream fs = new FileStream("students.json", FileMode.OpenOrCreate))
            {
                students = (List<StudentModel>)jsonFormatter.ReadObject(fs);
            }

            return students;
        }

        public ICommand BackToAdminPageCommand
        {
            get { return new DelegateCommand(BackToAdminPage); }
        }

        private void BackToAdminPage()
        {
            Application.Current.MainWindow.Content = new AdminPanel();
        }
    }
}
