﻿using System.Collections.Generic;

namespace UniversityLabApp.Models
{
    public class AdminCertification
    {
        public string Name { get; set; }

        public int Spot { get; set; }

        public List<CertificateModel> CertificateList { get; set; } = new List<CertificateModel>();
    }
}
