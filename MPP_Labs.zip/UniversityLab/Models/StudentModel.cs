﻿using System.Runtime.Serialization;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System;

namespace UniversityLabApp.Models
{
    [DataContract]
    public class StudentModel
    {
        [DataMember]
        public string FirstName { get; set; }

        [DataMember]
        public string SecondName { get; set; }

        [DataMember]
        public string Patronymic { get; set; }

        [DataMember]
        public DateTime Birthday { get; set; }

        [DataMember]
        public double AverageGrade { get; set; }

        [DataMember]
        public List<CertificateModel> Certificates { get; set; }

        [DataMember]
        public Dictionary<string, int> ExtraPoints { get; set; }

        [DataMember]
        public ObservableCollection<string> Specializations { get; set; }

        public bool IsEnrolled { get; set; }
    }
}
