﻿namespace UniversityLabApp.Models
{
    public class CertificateModel
    {
        public string NameSubject { get; set; }

        public double Grade { get; set; }
    }
}
