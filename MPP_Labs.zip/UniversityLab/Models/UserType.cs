﻿namespace UniversityLabApp.Models
{
    public enum UserType
    {
        Admin,
        Guest
    }

    public static class UserRole
    {
        public static UserType Role;
    }
}
