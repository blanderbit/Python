﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace UniversityLabApp.Converters
{
    public class BoolToText : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var IsEnrolled = System.Convert.ToBoolean(value);
            return IsEnrolled ? "Прошел" : "Не прошел";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
